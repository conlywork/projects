/**
 * Created by Conly on 2017/03/26.
 */
window.addEventListener('DOMContentLoaded', initPage, false);
window.addEventListener('resize', initPage, false);
function initPage() {
    var html = document.documentElement;
    var windowWidth = html.clientWidth;
    html.style.fontSize = windowWidth / 750 * 100 + 'px';
}

/**
 * Press Button Change This Style Css
 */
//Button Press
$(function(){
	$(".ul-lists li i").on("click",function(){
		var iDom=$(this);
		var jumpHref=iDom.parent("a").attr("data-href");
		var disabled=iDom.parent().parent("li").attr("class");
		var subStr=disabled.split(' ');
		for(var i=0;i<subStr.length;i++){
			if(subStr[i] == 'disabled'){
				iDom.parent("a").removeAttr("data-href");
				return false;
			}
		}
		iDom.addClass("active");
		setTimeout(function(){
			iDom.removeClass("active");
		},100);
		setTimeout(function(){
			location.href=jumpHref;
		},400);
	});
})
